%% EXERCISE 4 - PART 2-1
clc 
close all 
clear all 

% paths
addpath(genpath('PART II'))

%% TASK1
disp('===================================================================')
disp('PART 2-1')

%run the script 
disp('run the script in the PART II directory...')
task1