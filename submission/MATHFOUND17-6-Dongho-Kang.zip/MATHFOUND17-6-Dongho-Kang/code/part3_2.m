%% EXERCISE 6 - PART 3.1
clc
close all
clear all

% paths
addpath(genpath('Part 3 - Inpainting'))
addpath(genpath('functions'))


%% MAIN
disp('===================================================================')
disp('PART 3-2')
Inpainter;